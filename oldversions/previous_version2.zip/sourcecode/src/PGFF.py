#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author: Ivar Vargas Belizario
# Copyright (c) 2020
# E-mail: ivar@usp.br



from vx.pgff.Server import *


if __name__ == "__main__":
    Server.execute()




